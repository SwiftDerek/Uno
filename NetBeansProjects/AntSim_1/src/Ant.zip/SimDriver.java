/**
 *
 * @author Derek
 */
public class SimDriver {
    
    public static void main(String[] args){
        

        // create instance
        Simulation Sim = new Simulation();
        
    }
}
